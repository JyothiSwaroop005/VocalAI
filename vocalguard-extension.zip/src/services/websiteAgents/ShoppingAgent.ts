import type { WebsiteAgent, AgentResult, AgentStep } from './types';
import { openUrl, readActivePage } from '../chromeExtensionBridge';

export class ShoppingAgent implements WebsiteAgent {
  name = 'ShoppingAgent';

  canHandle(intent: string): boolean {
    const i = intent.toLowerCase();
    return i.includes('shop') || i.includes('buy') || i.includes('shoes') || i.includes('amazon') || i.includes('flipkart') || i.includes('product');
  }

  async execute(_intent: string, input: string): Promise<AgentResult> {
    const cleanInput = input.replace(/^(hey nova|nova|hi nova|okay nova),?\s*/i, '').trim();
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const prodMatch = cleanInput.match(/find\s+(.+?)(?:\s+under\s+.+)?$/i);
    const product = prodMatch ? prodMatch[1].trim() : cleanInput;
    const amazonUrl = `https://www.amazon.in/s?k=${encodeURIComponent(product)}`;

    const steps: AgentStep[] = [
      { id: 'shp1', label: 'Open Amazon Portal', status: 'completed', riskLevel: 'LOW', detail: `Searching Amazon for "${product}"` },
      { id: 'shp2', label: 'Extract Product Cards', status: 'completed', riskLevel: 'LOW', detail: 'Parsing visible items and prices' }
    ];

    await openUrl(amazonUrl, false);
    const pageSummary = await readActivePage();
    const resultCount = pageSummary?.headings.length || 10;

    return {
      success: true,
      intent: 'SHOPPING_SEARCH',
      completedSteps: steps,
      finalMessage: `Searching Amazon for "${product}". Found ${resultCount} listings.`,
      spokenResponse: `I found results for ${product} on Amazon.`,
      pageSummary: pageSummary || undefined,
      executionRecord: {
        action: 'shopping_search',
        target: product,
        status: 'VERIFIED',
        timestamp,
        evidence: { type: 'url', detail: amazonUrl }
      }
    };
  }
}

export const shoppingAgent = new ShoppingAgent();
