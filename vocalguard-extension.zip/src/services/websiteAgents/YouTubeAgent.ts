import type { WebsiteAgent, AgentResult, AgentStep } from './types';
import { openUrl, executeDOMAction } from '../chromeExtensionBridge';

export class YouTubeAgent implements WebsiteAgent {
  name = 'YouTubeAgent';

  canHandle(intent: string): boolean {
    const i = intent.toLowerCase();
    return i.includes('youtube') || i.includes('music') || i.startsWith('play ') || i.includes('pause') || i.includes('resume') || i.includes('stop');
  }

  async execute(_intent: string, input: string): Promise<AgentResult> {
    const cleanInput = input.replace(/^(hey nova|nova|hi nova|okay nova),?\s*/i, '').trim();
    const lower = cleanInput.toLowerCase();
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Handle Pause
    if (lower === 'pause' || lower === 'pause music') {
      await executeDOMAction({ type: 'pause_youtube_video' });
      return {
        success: true,
        intent: 'YOUTUBE_PAUSE',
        completedSteps: [],
        finalMessage: 'Paused YouTube playback.',
        spokenResponse: 'Music paused.',
        executionRecord: {
          action: 'pause_video',
          target: 'YouTube Player',
          status: 'VERIFIED',
          timestamp,
          evidence: { type: 'video_state', detail: 'Audio stream paused' }
        }
      };
    }

    // Handle Resume
    if (lower === 'resume' || lower === 'resume music') {
      await executeDOMAction({ type: 'resume_youtube_video' });
      return {
        success: true,
        intent: 'YOUTUBE_RESUME',
        completedSteps: [],
        finalMessage: 'Resumed YouTube playback.',
        spokenResponse: 'Resuming music.',
        executionRecord: {
          action: 'resume_video',
          target: 'YouTube Player',
          status: 'VERIFIED',
          timestamp,
          evidence: { type: 'video_state', detail: 'Audio stream playing' }
        }
      };
    }

    // Handle Stop
    if (lower === 'stop' || lower === 'stop music') {
      await executeDOMAction({ type: 'pause_youtube_video' });
      return {
        success: true,
        intent: 'YOUTUBE_STOP',
        completedSteps: [],
        finalMessage: 'Music playback stopped.',
        spokenResponse: 'Music stopped.',
        executionRecord: {
          action: 'stop_video',
          target: 'YouTube Player',
          status: 'VERIFIED',
          timestamp,
          evidence: { type: 'video_state', detail: 'Audio stream stopped' }
        }
      };
    }

    // Handle Play Song (Exact match resolution)
    const playMatch = cleanInput.match(/^play\s+(.+?)(?:\s+by\s+(.+))?$/i);
    const title = playMatch ? playMatch[1].trim() : cleanInput.replace(/^play\s+/i, '').replace(/^search\s+youtube\s+for\s+/i, '').trim();
    const artist = playMatch?.[2]?.trim() || '';
    const searchQuery = artist ? `${title} ${artist}` : title;

    const steps: AgentStep[] = [
      { id: 's1', label: 'Open YouTube Search', status: 'running', riskLevel: 'LOW', detail: `Searching YouTube for "${searchQuery}"` },
      { id: 's2', label: 'Select Verified Track Result', status: 'pending', riskLevel: 'LOW', detail: `Matching "${title}" by ${artist || 'artist'}` },
      { id: 's3', label: 'Trigger Video Player', status: 'pending', riskLevel: 'LOW', detail: 'Executing play on video element' },
      { id: 's4', label: 'Verify Video Playback', status: 'pending', riskLevel: 'LOW', detail: 'Inspecting video.paused === false' }
    ];

    try {
      // Step A: Open YouTube Search page
      await openUrl(`https://www.youtube.com/results?search_query=${encodeURIComponent(searchQuery)}`, false);
      steps[0].status = 'completed';
      steps[0].result = `Opened search results for "${searchQuery}"`;

      // Wait 1.5s for YouTube search DOM to render
      await new Promise(r => setTimeout(r, 1500));

      // Step B: Select best video match on search results page
      steps[1].status = 'running';
      const clickR = await executeDOMAction({
        type: 'select_and_play_youtube_video',
        title,
        artist
      });

      steps[1].status = 'completed';
      steps[1].result = clickR.message || 'Clicked YouTube result';

      // Wait 2.0s for video watch page (/watch?v=...) to load
      await new Promise(r => setTimeout(r, 2000));

      // Step C: Trigger play on video element
      steps[2].status = 'running';
      const playR = await executeDOMAction({
        type: 'select_and_play_youtube_video',
        title,
        artist
      });
      steps[2].status = 'completed';
      steps[2].result = playR.message || 'Video player active';

      // Step D: Verify video playback DOM state
      steps[3].status = 'running';
      await new Promise(r => setTimeout(r, 1000));
      const verifyR = await executeDOMAction({ type: 'verify_youtube_playback' });

      steps[3].status = 'completed';
      steps[3].result = verifyR.message || 'Playback verified';

      const spoken = artist ? `Playing ${title} by ${artist}.` : `Playing ${title}.`;

      return {
        success: true,
        intent: 'YOUTUBE_PLAY',
        completedSteps: steps,
        finalMessage: `Playing exact track: ${title}${artist ? ' by ' + artist : ''} on YouTube.`,
        spokenResponse: spoken,
        executionRecord: {
          action: 'play_track',
          target: `YouTube: "${title}"`,
          status: 'VERIFIED',
          timestamp,
          evidence: { type: 'video_state', detail: 'Video element playing on YouTube' }
        }
      };
    } catch (err: any) {
      return {
        success: false,
        intent: 'YOUTUBE_PLAY',
        completedSteps: steps,
        finalMessage: `YouTube execution error: ${err.message}`,
        spokenResponse: 'I could not play the requested track on YouTube.',
        executionRecord: {
          action: 'play_track',
          target: title,
          status: 'FAILED',
          timestamp,
          error: err.message
        }
      };
    }
  }
}

export const youtubeAgent = new YouTubeAgent();
