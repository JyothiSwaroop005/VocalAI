export type VoiceState =
  | 'IDLE'
  | 'LISTENING_FOR_WAKE'
  | 'WAKE_DETECTED'
  | 'CAPTURING_COMMAND'
  | 'PROCESSING'
  | 'EXECUTING'
  | 'SPEAKING'
  | 'ERROR'
  | 'WAITING_FOR_CONFIRMATION';

export type MicPermissionState =
  | 'MIC_PERMISSION_REQUIRED'
  | 'MIC_PERMISSION_GRANTED'
  | 'MIC_PERMISSION_DENIED'
  | 'MIC_UNAVAILABLE';

export interface SpeechEngineCallbacks {
  onStateChange?: (state: VoiceState) => void;
  onWakeWordDetected?: () => void;
  onSpeechStart?: () => void;
  onSpeechResult?: (transcript: string, isFinal: boolean) => void;
  onCommandCaptured?: (command: string) => void;
  onSpeechEnd?: () => void;
  onError?: (error: string) => void;
  onDiagnosticUpdate?: (diag: VoiceDiagnosticState) => void;
}

export interface VoiceDiagnosticState {
  browser: string;
  micPermission: MicPermissionState;
  speechRecognitionSupported: boolean;
  speechSynthesisSupported: boolean;
  recognitionState: string;
  currentInterimTranscript: string;
  lastFinalCommand: string;
  lastError: string | null;
  novaState: VoiceState;
  pendingActionType: string | null;
}

export class VoiceEngine {
  private recognition: any = null;
  private isListening: boolean = false;
  private isSupported: boolean = false;
  private currentState: VoiceState = 'IDLE';
  private micPermission: MicPermissionState = 'MIC_PERMISSION_REQUIRED';
  private callbacks: SpeechEngineCallbacks = {};
  private silenceTimer: any = null;
  private wakeWords: string[] = ['hey nova', 'nova', 'hi nova', 'okay nova'];
  private isSpeakingTTS: boolean = false;
  private autoRestartWakeLoop: boolean = false;

  private currentInterimTranscript: string = '';
  private lastFinalCommand: string = '';
  private lastError: string | null = null;
  private pendingActionType: string | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        this.isSupported = true;
        try {
          this.recognition = new SpeechRecognition();
          this.recognition.continuous = true;
          this.recognition.interimResults = true;
          this.recognition.lang = 'en-US';
        } catch (e) {
          console.warn('SpeechRecognition initialization error:', e);
          this.isSupported = false;
        }
      }

      this.checkMicPermission();
    }
  }

  public checkSupport(): boolean {
    return this.isSupported;
  }

  public getState(): VoiceState {
    return this.currentState;
  }

  public setPendingActionType(type: string | null) {
    this.pendingActionType = type;
    this.notifyDiagnostics();
  }

  public async checkMicPermission(): Promise<MicPermissionState> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices) {
      this.micPermission = 'MIC_UNAVAILABLE';
      this.notifyDiagnostics();
      return this.micPermission;
    }

    try {
      if (navigator.permissions && navigator.permissions.query) {
        const status = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        if (status.state === 'granted') this.micPermission = 'MIC_PERMISSION_GRANTED';
        else if (status.state === 'denied') this.micPermission = 'MIC_PERMISSION_DENIED';
        else this.micPermission = 'MIC_PERMISSION_REQUIRED';

        status.onchange = () => {
          if (status.state === 'granted') this.micPermission = 'MIC_PERMISSION_GRANTED';
          else if (status.state === 'denied') this.micPermission = 'MIC_PERMISSION_DENIED';
          this.notifyDiagnostics();
        };
      }
    } catch (_) {
      // Fallback
    }

    this.notifyDiagnostics();
    return this.micPermission;
  }

  public async requestMicPermission(): Promise<boolean> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      this.micPermission = 'MIC_UNAVAILABLE';
      this.notifyDiagnostics();
      return false;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop());
      this.micPermission = 'MIC_PERMISSION_GRANTED';
      this.lastError = null;
      this.notifyDiagnostics();
      return true;
    } catch (err: any) {
      console.warn('[MIC PERMISSION REQUEST ERROR]', err);
      this.micPermission = 'MIC_PERMISSION_DENIED';
      this.lastError = 'Microphone permission denied by user or browser policy.';
      this.notifyDiagnostics();
      return false;
    }
  }

  public getDiagnostics(): VoiceDiagnosticState {
    const isChrome = typeof window !== 'undefined' && !!(window as any).chrome;
    const isSynthSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

    return {
      browser: isChrome ? 'Google Chrome' : 'Standard Web Browser',
      micPermission: this.micPermission,
      speechRecognitionSupported: this.isSupported,
      speechSynthesisSupported: isSynthSupported,
      recognitionState: this.isListening ? 'Listening' : 'Idle',
      currentInterimTranscript: this.currentInterimTranscript,
      lastFinalCommand: this.lastFinalCommand,
      lastError: this.lastError,
      novaState: this.currentState,
      pendingActionType: this.pendingActionType
    };
  }

  private notifyDiagnostics() {
    this.callbacks.onDiagnosticUpdate?.(this.getDiagnostics());
  }

  private setState(newState: VoiceState) {
    console.log(`[VOICE STATE MACHINE] ${this.currentState} → ${newState}`);
    this.currentState = newState;
    this.callbacks.onStateChange?.(newState);
    this.notifyDiagnostics();
  }

  /**
   * Hands-Free Wake Word Engine & Continuous Listener
   */
  public startHandsFreeEngine(callbacks: SpeechEngineCallbacks): boolean {
    this.callbacks = callbacks;
    this.autoRestartWakeLoop = true;

    if (!this.isSupported || !this.recognition) {
      this.setState('ERROR');
      this.lastError = 'Web Speech API is not supported in this browser.';
      callbacks.onError?.(this.lastError);
      this.notifyDiagnostics();
      return false;
    }

    try {
      this.setState('LISTENING_FOR_WAKE');
      this.setupRecognitionListeners();
      this.recognition.start();
      this.micPermission = 'MIC_PERMISSION_GRANTED';
      this.notifyDiagnostics();
      return true;
    } catch (err: any) {
      console.error('[HANDS-FREE ENGINE] Failed to start:', err);
      this.setState('ERROR');
      this.lastError = err.message || 'Microphone access denied';
      callbacks.onError?.(this.lastError || 'Microphone access denied');
      this.notifyDiagnostics();
      return false;
    }
  }

  private setupRecognitionListeners() {
    this.recognition.onstart = () => {
      this.isListening = true;
      this.micPermission = 'MIC_PERMISSION_GRANTED';
      this.notifyDiagnostics();
    };

    this.recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const text = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += text;
        } else {
          interimTranscript += text;
        }
      }

      const fullText = (finalTranscript || interimTranscript).trim();
      if (!fullText) return;

      this.currentInterimTranscript = interimTranscript || fullText;
      this.notifyDiagnostics();

      // REQUIREMENT 13: Conversational Interruption!
      // If Nova is speaking (TTS active) and user starts speaking -> Cancel TTS immediately & capture user input!
      if (this.isSpeakingTTS || this.currentState === 'SPEAKING') {
        console.log('[USER INTERRUPT] User spoke during TTS — cancelling speech synthesis immediately!');
        this.stopSpeaking();
        this.setState('CAPTURING_COMMAND');
      }

      const lowerText = fullText.toLowerCase();

      // State 1: LISTENING_FOR_WAKE
      if (this.currentState === 'LISTENING_FOR_WAKE' || this.currentState === 'IDLE') {
        const matchedWakeWord = this.wakeWords.find(w => lowerText.includes(w));
        if (matchedWakeWord) {
          console.log(`[WAKE WORD DETECTED] Triggered by phrase: "${matchedWakeWord}" in text: "${fullText}"`);
          this.setState('WAKE_DETECTED');
          this.callbacks.onWakeWordDetected?.();

          // Extract command payload following the wake phrase if spoken in same sentence
          let cleanCommand = fullText;
          for (const w of this.wakeWords) {
            cleanCommand = cleanCommand.replace(new RegExp(`^.*?${w}\\s*,?\\s*`, 'i'), '');
          }
          cleanCommand = cleanCommand.trim();

          if (cleanCommand.length > 1) {
            console.log(`[INSTANT COMMAND CAPTURED] Single-sentence execution: "${cleanCommand}"`);
            this.lastFinalCommand = cleanCommand;
            this.currentInterimTranscript = '';
            this.setState('PROCESSING');
            this.callbacks.onCommandCaptured?.(cleanCommand);
          } else {
            setTimeout(() => {
              this.setState('CAPTURING_COMMAND');
            }, 300);
          }
        }
      } 
      // State 2: CAPTURING_COMMAND (User is speaking their command)
      else if (this.currentState === 'CAPTURING_COMMAND') {
        // Strip wake phrase if present at start
        let cleanCommand = fullText;
        for (const w of this.wakeWords) {
          cleanCommand = cleanCommand.replace(new RegExp(`^${w}\\s*,?\\s*`, 'i'), '');
        }

        this.callbacks.onSpeechResult?.(cleanCommand, !!finalTranscript);

        if (this.silenceTimer) clearTimeout(this.silenceTimer);

        // Instant submit on final speech result
        if (finalTranscript && cleanCommand.trim().length > 1) {
          console.log(`[FINAL TRANSCRIPT SUBMIT] Submitting command immediately: "${cleanCommand}"`);
          this.lastFinalCommand = cleanCommand.trim();
          this.currentInterimTranscript = '';
          this.setState('PROCESSING');
          this.stopListening();
          this.callbacks.onCommandCaptured?.(cleanCommand.trim());
          return;
        }

        if (cleanCommand.trim().length > 1) {
          this.silenceTimer = setTimeout(() => {
            console.log(`[VAD SILENCE DETECTED] Submitting command: "${cleanCommand}"`);
            this.lastFinalCommand = cleanCommand.trim();
            this.currentInterimTranscript = '';
            this.setState('PROCESSING');
            this.stopListening();
            this.callbacks.onCommandCaptured?.(cleanCommand.trim());
          }, 600);
        }
      }
    };

    this.recognition.onerror = (event: any) => {
      console.warn('[SPEECH RECOGNITION NOTE]', event.error);
      this.lastError = `Speech recognition note: ${event.error}`;

      if (event.error === 'not-allowed') {
        this.micPermission = 'MIC_PERMISSION_DENIED';
        this.setState('ERROR');
        this.callbacks.onError?.('Microphone access is blocked. Allow microphone access for localhost in Chrome.');
      } else if (event.error === 'no-speech') {
        // Soft timeout — restart listening gracefully
      }
      this.notifyDiagnostics();
    };

    this.recognition.onend = () => {
      this.isListening = false;
      this.notifyDiagnostics();

      // Auto-restart loop if in continuous listening mode & not speaking TTS
      if (this.autoRestartWakeLoop && !this.isSpeakingTTS && this.currentState !== 'PROCESSING' && this.currentState !== 'EXECUTING') {
        setTimeout(() => {
          try {
            if (!this.isListening) {
              this.setState('LISTENING_FOR_WAKE');
              this.recognition.start();
            }
          } catch (_) {}
        }, 500);
      }
    };
  }

  public manualStartListening(callbacks: SpeechEngineCallbacks): boolean {
    return this.startHandsFreeEngine(callbacks);
  }

  public stopListening() {
    if (this.silenceTimer) clearTimeout(this.silenceTimer);
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (_) {}
      this.isListening = false;
      this.notifyDiagnostics();
    }
  }

  public stopHandsFreeEngine() {
    this.autoRestartWakeLoop = false;
    this.stopListening();
    this.setState('IDLE');
  }

  /**
   * Speak Nova response aloud with TTS Self-Hearing Protection & Interruption Support
   */
  public speak(text: string, onEnd?: () => void) {
    if (typeof window === 'undefined') {
      if (onEnd) onEnd();
      return;
    }

    // Pause microphone input while speaking to prevent self-hearing loop
    this.isSpeakingTTS = true;
    this.stopListening();
    this.setState('SPEAKING');

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.05;
      utterance.volume = 1.0;

      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(
        v => v.lang.startsWith('en') && (v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Samantha') || v.name.includes('Karen'))
      );
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      const handleSpeechDone = () => {
        this.isSpeakingTTS = false;
        console.log('[TTS COMPLETED] Resuming hands-free wake word listening...');
        if (onEnd) onEnd();

        // Resume hands-free wake word loop after TTS finishes
        if (this.autoRestartWakeLoop) {
          setTimeout(() => {
            this.setState('LISTENING_FOR_WAKE');
            try {
              if (!this.isListening) this.recognition.start();
            } catch (_) {}
          }, 400);
        } else {
          this.setState('IDLE');
        }
      };

      utterance.onend = handleSpeechDone;
      utterance.onerror = handleSpeechDone;

      window.speechSynthesis.speak(utterance);
    } else {
      if (onEnd) setTimeout(onEnd, 1500);
    }
  }

  public stopSpeaking() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.isSpeakingTTS = false;
  }
}

export const voiceEngine = new VoiceEngine();
